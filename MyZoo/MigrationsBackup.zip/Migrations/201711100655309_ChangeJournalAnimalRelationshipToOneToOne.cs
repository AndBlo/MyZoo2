namespace MyZoo.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangeJournalAnimalRelationshipToOneToOne : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Journals", "AnimalId", "dbo.Animals");
            DropForeignKey("dbo.JournalsDiagnoses", "JournalId", "dbo.Journals");
            DropIndex("dbo.Journals", new[] { "AnimalId" });
            DropColumn("dbo.Journals", "JournalId");
            RenameColumn(table: "dbo.Journals", name: "AnimalId", newName: "JournalId");
            DropPrimaryKey("dbo.Journals");
            AddColumn("dbo.Animals", "JournalId", c => c.Int());
            AlterColumn("dbo.Journals", "JournalId", c => c.Int(nullable: false));
            AddPrimaryKey("dbo.Journals", "JournalId");
            CreateIndex("dbo.Journals", "JournalId");
            AddForeignKey("dbo.Journals", "JournalId", "dbo.Animals", "AnimalId");
            AddForeignKey("dbo.JournalsDiagnoses", "JournalId", "dbo.Journals", "JournalId", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.JournalsDiagnoses", "JournalId", "dbo.Journals");
            DropForeignKey("dbo.Journals", "JournalId", "dbo.Animals");
            DropIndex("dbo.Journals", new[] { "JournalId" });
            DropPrimaryKey("dbo.Journals");
            AlterColumn("dbo.Journals", "JournalId", c => c.Int(nullable: false, identity: true));
            DropColumn("dbo.Animals", "JournalId");
            AddPrimaryKey("dbo.Journals", "JournalId");
            RenameColumn(table: "dbo.Journals", name: "JournalId", newName: "AnimalId");
            AddColumn("dbo.Journals", "JournalId", c => c.Int(nullable: false, identity: true));
            CreateIndex("dbo.Journals", "AnimalId");
            AddForeignKey("dbo.JournalsDiagnoses", "JournalId", "dbo.Journals", "JournalId", cascadeDelete: true);
            AddForeignKey("dbo.Journals", "AnimalId", "dbo.Animals", "AnimalId", cascadeDelete: true);
        }
    }
}
