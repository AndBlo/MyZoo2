namespace MyZoo.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangeMedicationsJournalsDiagnosRelationshipToOneToMany : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.JournalsDiagnoses", "MedicationId", "dbo.Medications");
            DropIndex("dbo.JournalsDiagnoses", new[] { "MedicationId" });
            CreateTable(
                "dbo.MedicationJournalsDiagnos",
                c => new
                    {
                        Medication_MedicationId = c.Int(nullable: false),
                        JournalsDiagnos_JournalDiagnoseId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Medication_MedicationId, t.JournalsDiagnos_JournalDiagnoseId })
                .ForeignKey("dbo.Medications", t => t.Medication_MedicationId, cascadeDelete: true)
                .ForeignKey("dbo.JournalsDiagnoses", t => t.JournalsDiagnos_JournalDiagnoseId, cascadeDelete: true)
                .Index(t => t.Medication_MedicationId)
                .Index(t => t.JournalsDiagnos_JournalDiagnoseId);
            
            DropColumn("dbo.JournalsDiagnoses", "MedicationId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.JournalsDiagnoses", "MedicationId", c => c.Int());
            DropForeignKey("dbo.MedicationJournalsDiagnos", "JournalsDiagnos_JournalDiagnoseId", "dbo.JournalsDiagnoses");
            DropForeignKey("dbo.MedicationJournalsDiagnos", "Medication_MedicationId", "dbo.Medications");
            DropIndex("dbo.MedicationJournalsDiagnos", new[] { "JournalsDiagnos_JournalDiagnoseId" });
            DropIndex("dbo.MedicationJournalsDiagnos", new[] { "Medication_MedicationId" });
            DropTable("dbo.MedicationJournalsDiagnos");
            CreateIndex("dbo.JournalsDiagnoses", "MedicationId");
            AddForeignKey("dbo.JournalsDiagnoses", "MedicationId", "dbo.Medications", "MedicationId");
        }
    }
}
